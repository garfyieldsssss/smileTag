gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDPlayer1Objects1= [];
gdjs.Untitled_32sceneCode.GDPlayer1Objects2= [];
gdjs.Untitled_32sceneCode.GDBorderObjects1= [];
gdjs.Untitled_32sceneCode.GDBorderObjects2= [];
gdjs.Untitled_32sceneCode.GDPlayer3Objects1= [];
gdjs.Untitled_32sceneCode.GDPlayer3Objects2= [];
gdjs.Untitled_32sceneCode.GDfallgroundObjects1= [];
gdjs.Untitled_32sceneCode.GDfallgroundObjects2= [];
gdjs.Untitled_32sceneCode.GDGroundObjects1= [];
gdjs.Untitled_32sceneCode.GDGroundObjects2= [];
gdjs.Untitled_32sceneCode.GDConeObjects1= [];
gdjs.Untitled_32sceneCode.GDConeObjects2= [];
gdjs.Untitled_32sceneCode.GDcheeseObjects1= [];
gdjs.Untitled_32sceneCode.GDcheeseObjects2= [];
gdjs.Untitled_32sceneCode.GDPlayer2Objects1= [];
gdjs.Untitled_32sceneCode.GDPlayer2Objects2= [];
gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects1= [];
gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects2= [];
gdjs.Untitled_32sceneCode.GDtriangleOrangeObjects1= [];
gdjs.Untitled_32sceneCode.GDtriangleOrangeObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDbgObjects1= [];
gdjs.Untitled_32sceneCode.GDbgObjects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer1Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer3Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player1": gdjs.Untitled_32sceneCode.GDPlayer1Objects1, "Player3": gdjs.Untitled_32sceneCode.GDPlayer3Objects1, "Player2": gdjs.Untitled_32sceneCode.GDPlayer2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.Untitled_32sceneCode.GDPlayer1Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.Untitled_32sceneCode.GDPlayer2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.Untitled_32sceneCode.GDPlayer1Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer3Objects1Objects = Hashtable.newFrom({"Player3": gdjs.Untitled_32sceneCode.GDPlayer3Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.Untitled_32sceneCode.GDPlayer2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.Untitled_32sceneCode.GDPlayer1Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.Untitled_32sceneCode.GDPlayer2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer3Objects1Objects = Hashtable.newFrom({"Player3": gdjs.Untitled_32sceneCode.GDPlayer3Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer3Objects1Objects = Hashtable.newFrom({"Player3": gdjs.Untitled_32sceneCode.GDPlayer3Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer1Objects1Objects = Hashtable.newFrom({"Player1": gdjs.Untitled_32sceneCode.GDPlayer1Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer3Objects1Objects = Hashtable.newFrom({"Player3": gdjs.Untitled_32sceneCode.GDPlayer3Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer2Objects1Objects = Hashtable.newFrom({"Player2": gdjs.Untitled_32sceneCode.GDPlayer2Objects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Untitled_32sceneCode.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.Untitled_32sceneCode.GDPlayer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player3"), gdjs.Untitled_32sceneCode.GDPlayer3Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getBehavior("RemapForPlatformer").SetCustom("w", "a", "s", "d", "w", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getBehavior("RemapForPlatformer").SetCustom("Up", "Left", "Down", "Right", "Up", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtsExt__FollowObjectsWithCamera__FollowMultipleObjectsWithCamera.func(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer1Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer3Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer2Objects1Objects, 200, 200, 0, 0.7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getBehavior("RemapForPlatformer").SetCustom("i", "j", "k", "l", "i", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("bg"), gdjs.Untitled_32sceneCode.GDbgObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(100);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbgObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbgObjects1[i].getBehavior("Opacity").setOpacity(30);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "sTART", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "timesincetag", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "gametime", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TIME_LEFT"), gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(-(999999));
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects1[i].getBehavior("Text").setText("Game Over! Press ESC to go to menu");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects1[i].setCharacterSize(40);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Untitled_32sceneCode.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.Untitled_32sceneCode.GDPlayer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player3"), gdjs.Untitled_32sceneCode.GDPlayer3Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].variableRemoveChild(gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariables().get("inPlay"), "Player2");
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].variableRemoveChild(gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariables().get("inPlay"), "Player2");
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].variableRemoveChild(gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariables().get("inPlay"), "Player2");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TIME_LEFT"), gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(1).getAsString());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Untitled_32sceneCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer1Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer1Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getBehavior("Animation").setAnimationName("IT1");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getBehavior("PlatformerConfigurationStack").ConfigureMaxSpeed(1100, "plr1", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player3"), gdjs.Untitled_32sceneCode.GDPlayer3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer3Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer3Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getBehavior("Animation").setAnimationName("IT3");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getBehavior("PlatformerConfigurationStack").ConfigureMaxSpeed(1100, "plr3", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.Untitled_32sceneCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer2Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getBehavior("Animation").setAnimationName("IT2");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getBehavior("PlatformerConfigurationStack").ConfigureMaxSpeed(1100, "plr2", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Untitled_32sceneCode.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.Untitled_32sceneCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer1Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer1Objects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 3;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer1Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Untitled_32sceneCode.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player3"), gdjs.Untitled_32sceneCode.GDPlayer3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer1Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer1Objects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 3;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer1Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer3Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Untitled_32sceneCode.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.Untitled_32sceneCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer2Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer2Objects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer1Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 3;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer1Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.Untitled_32sceneCode.GDPlayer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player3"), gdjs.Untitled_32sceneCode.GDPlayer3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer2Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer2Objects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 3;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer2Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer3Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Untitled_32sceneCode.GDPlayer1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player3"), gdjs.Untitled_32sceneCode.GDPlayer3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer3Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer3Objects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer1Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 3;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer1Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer3Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.Untitled_32sceneCode.GDPlayer2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player3"), gdjs.Untitled_32sceneCode.GDPlayer3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer3Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer3Objects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 3;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer2Objects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer3Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player1"), gdjs.Untitled_32sceneCode.GDPlayer1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer1Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer1Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getBehavior("Animation").setAnimationName("NewSprite");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer1Objects1[i].getBehavior("PlatformerConfigurationStack").ConfigureMaxSpeed(1000, "plr1", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player2"), gdjs.Untitled_32sceneCode.GDPlayer2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer2Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getBehavior("Animation").setAnimationName("NewSprite");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer2Objects1[i].getBehavior("PlatformerConfigurationStack").ConfigureMaxSpeed(1000, "plr2", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player3"), gdjs.Untitled_32sceneCode.GDPlayer3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer3Objects1[k] = gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer3Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getBehavior("PlatformerConfigurationStack").ConfigureMaxSpeed(1000, "plr3", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer3Objects1[i].getBehavior("Animation").setAnimationName("NewSprite");
}
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDPlayer1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBorderObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBorderObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDfallgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDfallgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDConeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDConeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcheeseObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDcheeseObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTIME_9595LEFTObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtriangleOrangeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtriangleOrangeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
