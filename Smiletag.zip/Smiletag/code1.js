gdjs.sTARTCode = {};
gdjs.sTARTCode.GDLogoObjects1= [];
gdjs.sTARTCode.GDLogoObjects2= [];
gdjs.sTARTCode.GDPlayBTNObjects1= [];
gdjs.sTARTCode.GDPlayBTNObjects2= [];
gdjs.sTARTCode.GDcreditsObjects1= [];
gdjs.sTARTCode.GDcreditsObjects2= [];
gdjs.sTARTCode.GDmenu_9595additiveObjects1= [];
gdjs.sTARTCode.GDmenu_9595additiveObjects2= [];
gdjs.sTARTCode.GD_95952PLRBTNObjects1= [];
gdjs.sTARTCode.GD_95952PLRBTNObjects2= [];
gdjs.sTARTCode.GD_95953PLRBTNObjects1= [];
gdjs.sTARTCode.GD_95953PLRBTNObjects2= [];
gdjs.sTARTCode.GDcontrolsObjects1= [];
gdjs.sTARTCode.GDcontrolsObjects2= [];


gdjs.sTARTCode.mapOfGDgdjs_9546sTARTCode_9546GD_959595952PLRBTNObjects1Objects = Hashtable.newFrom({"_2PLRBTN": gdjs.sTARTCode.GD_95952PLRBTNObjects1});
gdjs.sTARTCode.mapOfGDgdjs_9546sTARTCode_9546GD_959595953PLRBTNObjects1Objects = Hashtable.newFrom({"_3PLRBTN": gdjs.sTARTCode.GD_95953PLRBTNObjects1});
gdjs.sTARTCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("_2PLRBTN"), gdjs.sTARTCode.GD_95952PLRBTNObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sTARTCode.mapOfGDgdjs_9546sTARTCode_9546GD_959595952PLRBTNObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("_3PLRBTN"), gdjs.sTARTCode.GD_95953PLRBTNObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.sTARTCode.mapOfGDgdjs_9546sTARTCode_9546GD_959595953PLRBTNObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


};

gdjs.sTARTCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.sTARTCode.GDLogoObjects1.length = 0;
gdjs.sTARTCode.GDLogoObjects2.length = 0;
gdjs.sTARTCode.GDPlayBTNObjects1.length = 0;
gdjs.sTARTCode.GDPlayBTNObjects2.length = 0;
gdjs.sTARTCode.GDcreditsObjects1.length = 0;
gdjs.sTARTCode.GDcreditsObjects2.length = 0;
gdjs.sTARTCode.GDmenu_9595additiveObjects1.length = 0;
gdjs.sTARTCode.GDmenu_9595additiveObjects2.length = 0;
gdjs.sTARTCode.GD_95952PLRBTNObjects1.length = 0;
gdjs.sTARTCode.GD_95952PLRBTNObjects2.length = 0;
gdjs.sTARTCode.GD_95953PLRBTNObjects1.length = 0;
gdjs.sTARTCode.GD_95953PLRBTNObjects2.length = 0;
gdjs.sTARTCode.GDcontrolsObjects1.length = 0;
gdjs.sTARTCode.GDcontrolsObjects2.length = 0;

gdjs.sTARTCode.eventsList0(runtimeScene);

return;

}

gdjs['sTARTCode'] = gdjs.sTARTCode;
